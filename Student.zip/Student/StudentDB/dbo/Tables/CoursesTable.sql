﻿CREATE TABLE [dbo].[CoursesTable]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [CourseId] INT NOT NULL, 
    [CourseName] NVARCHAR(50) NOT NULL, 
    [CourseTeacher] NVARCHAR(50) NOT NULL, 
    [StartDate] DATETIME NOT NULL, 
    [EndDate] DATETIME NOT NULL,
	[SPACES] INT NOT NULL, 
    [Students] INT NOT NULL DEFAULT 0
)
