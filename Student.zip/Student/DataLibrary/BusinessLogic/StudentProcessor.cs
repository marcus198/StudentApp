﻿using DataLibrary.DataAccess;
using DataLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.BusinessLogic
{
    public static class StudentProcessor
    {
        public static int CreateStudent(int studentId, string firstName, string lastName,
            int gender, DateTime dob, string address1, string address2, string address3, string course1, 
            string course2, string course3, string course4, string course5)
        {
            StudentModel data = new StudentModel
            {
                StudentId = studentId,
                FirstName = firstName,
                LastName = lastName,
                Gender = gender,
                DOB = dob,
                Address1 = address1,
                Address2 = address2,
                Address3 = address3,
                Course1 = course1,
                Course2 = course2,
                Course3 = course3,
                Course4 = course4,
                Course5 = course5
            };

            string sql = @"insert into dbo.StudentTable (StudentId, FirstName, LastName, Gender, DOB, Address1, Address2, Address3, Course1, Course2, Course3, Course4, Course5)
                            values (@StudentId, @FirstName, @LastName, @Gender, @DOB, @Address1 , @Address2, @Address3, @Course1, @Course2, @Course3, @Course4, @Course5 );";

            return SqlDataAccess.SaveData(sql, data);
        }
        public static List<StudentModel> LoadStudents()
        {
            string sql = @"select Id, StudentId, FirstName, LastName, Gender, DOB, Address1, Address2, Address3, Course1, Course2, Course3, Course4, Course5
                            from dbo.StudentTable;";
            return SqlDataAccess.LoadData<StudentModel>(sql);
        }
        public static List<StudentModel> LoadStudentsNotMaxCourse()
        {
            string sql = @"select * from dbo.StudentTable where Course1 is NULL or Course2 is NULL or Course3 is NULL or Course4 is NULL or Course4 is NULL or Course5 is NULL;";
            return SqlDataAccess.LoadData<StudentModel>(sql);
        }
        public static List<StudentModel> LoadStudentsByCourseName(string courseName)
        {
            string sql = @"select* from dbo.StudentTable where Course1 = '" + courseName + "' or Course2 = '" + courseName + "' or Course3 = '" + courseName + "' or Course4 = '" + courseName + "'or Course5 = '" + courseName + "';";
            return SqlDataAccess.LoadData<StudentModel>(sql);
        }
        public static int DeleteStudent(int studentId)
        {
            string sql = @"delete from dbo.StudentTable where StudentId='" +  studentId + "';";
            return SqlDataAccess.DeleteData<StudentModel>(sql);
        }
        public static StudentModel SelectStudent(int studentId)
        {
            string sql = @"select * from dbo.StudentTable where StudentId =" + studentId + ";";
            return SqlDataAccess.SelectRow<StudentModel>(sql);
        }
        public static StudentModel SelectStudentByName(string name)
        {
            string sql = @"select * from dbo.StudentTable where FirstName =" + name + ";";
            return SqlDataAccess.SelectRow<StudentModel>(sql);
        }
        public static int UpdateStudent(int studentId, string firstName, string lastName,
            int gender, DateTime dob, string address1, string address2, string address3, string course1,
            string course2, string course3, string course4, string course5)
        {
            string sql = @"update dbo.StudentTable set FirstName = '" + firstName + 
                "', LastName = '" + lastName + 
                "', Gender = '" + gender + 
                "', DOB = '" + dob + 
                "', Address1 = '" + address1 + 
                "', Address2 = '" + address2 + 
                "', Address3 = '" + address3 +
                "', Course1 = '" + course1 +
                "', Course2 = '" + course2 +
                "', Course3 = '" + course3 +
                "', Course4 = '" + course4 +
                "', Course5 = '" + course5 +
                "' WHERE StudentId = " + studentId + ";";
            return SqlDataAccess.UdpateRecord(sql);
        }
    }
}
