﻿using DataLibrary.DataAccess;
using DataLibrary.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLibrary.BusinessLogic
{
    public static class CourseProcessor
    {
        public static int CreateCourse(int courseId, string courseName, string courseTeacher,
             DateTime startDate, DateTime endDate, int spaces, int students = 0)
        {
            CourseModel data = new CourseModel
            {
                CourseId = courseId,
                CourseName = courseName,
                CourseTeacher = courseTeacher,
                StartDate = startDate,
                EndDate = endDate,
                Spaces = spaces,
                Students = students
            };

            string sql = @"insert into dbo.CoursesTable (CourseId, CourseName, CourseTeacher, StartDate, EndDate, Spaces, Students)
                            values (@CourseId, @CourseName, @CourseTeacher, @StartDate, @EndDate, @Spaces, @Students);";

            return SqlDataAccess.SaveData(sql, data);
        }
        public static List<CourseModel> LoadCourses()
        {
            string sql = @"select Id, CourseId, CourseName, CourseTeacher, StartDate, EndDate, Spaces, Students
                            from dbo.CoursesTable;";
            return SqlDataAccess.LoadData<CourseModel>(sql);
        }
        public static List<CourseModel> LoadCoursesWithSpace()
        {
            string sql = @"select * from dbo.CoursesTable where Spaces > 0;";
            return SqlDataAccess.LoadData<CourseModel>(sql);
        }
        public static CourseModel SelectCourse(int courseId)
        {
            string sql = @"select * from dbo.CoursesTable where CourseId =" + courseId + ";";
            return SqlDataAccess.SelectRow<CourseModel>(sql);
        }
        public static List<CourseModel> SelectCourseByNames(string course1, string course2, string course3, string course4, string course5)
        {
            string sql = @"select * from dbo.CoursesTable where CourseName = '" + course1 + "' or CourseName = '" + course2 + "' or CourseName = '" + course3 + "' or CourseName = '" + course4 + "' or CourseName = '" + course5 + "'; ";
            return SqlDataAccess.LoadData<CourseModel>(sql);
        }
        public static int DeleteCourse(int courseId)
        {
            string sql = @"delete from dbo.CoursesTable where CourseId='" + courseId + "';";
            return SqlDataAccess.DeleteData<StudentModel>(sql);
        }
        public static int UpdateCourse(int courseId, string courseName, string courseTeacher,
             DateTime startDate, DateTime endDate, int spaces, int students)
        {
            string sql = @"update dbo.CoursesTable set CourseName = '" + courseName +
                "', CourseTeacher = '" + courseTeacher +
                "', StartDate = '" + startDate +
                "', EndDate = '" + endDate +
                "', Spaces = '" + spaces +
                "', Students = '" + students +
                "' WHERE CourseId = " + courseId;
            return SqlDataAccess.UdpateRecord(sql);
        }
        public static int UpdateCourseFromStudentEnrolment(string courseName)
        {
            if (String.IsNullOrEmpty(courseName))
            {
                return -1;
            }
            string sql = @"update dbo.CoursesTable set spaces = spaces - 1, students = students + 1 WHERE CourseName = '" + courseName + "';";
            return SqlDataAccess.UdpateRecord(sql);
        }
        public static int UpdateCourseFromStudentDeletion(string courseName)
        {
            if (String.IsNullOrEmpty(courseName))
            {
                return -1;
            }
            string sql = @"update dbo.CoursesTable set spaces = spaces + 1, students = students - 1 WHERE CourseName = '" + courseName + "';";
            return SqlDataAccess.UdpateRecord(sql);
        }
    }
}
