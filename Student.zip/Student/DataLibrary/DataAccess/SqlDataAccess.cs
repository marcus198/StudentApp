﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Dapper;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace DataLibrary.DataAccess
{
    public static class SqlDataAccess
    {
        public static string GetCoNnectionString(string connectionName = "StudentDB")
        {
            return ConfigurationManager.ConnectionStrings[connectionName].ConnectionString;
        }

        public static List<T> LoadData<T>(String sql)
        {
            using (IDbConnection cnn = new SqlConnection(GetCoNnectionString()))
            {
                return cnn.Query<T>(sql).ToList();
            }
        }
        public static int SaveData<T>(string sql, T data)
        {
            using (IDbConnection cnn = new SqlConnection(GetCoNnectionString()))
            {
                return cnn.Execute(sql, data);
            }
        }
        public static int DeleteData<T>(string sql)
        {
            using (IDbConnection cnn = new SqlConnection(GetCoNnectionString()))
            {
                return cnn.Execute(sql);
            }
        }
        public static T SelectRow<T>(string sql)
        {
            using (IDbConnection cnn = new SqlConnection(GetCoNnectionString()))
            {
                try
                {
                    return cnn.QuerySingle<T>(sql);
                }
                catch
                {
                    return default(T);
                }
                
            }
        }
        public static int UdpateRecord(string sql)
        {
            using (IDbConnection cnn = new SqlConnection(GetCoNnectionString()))
            {
                return cnn.Execute(sql);
            }
        }
    }
}
