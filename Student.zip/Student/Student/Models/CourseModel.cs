﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;
using System.Linq;
using System.Web;

namespace Student.Models
{
    public class CourseModel
    {
        [Required]
        [Display(Name = "Course ID")]
        [Range(100000, 999999, ErrorMessage = "You need to enter a valid Course ID")]
        public int CourseId { get; set; }

        [Required(ErrorMessage = "Course Name required")]
        [Display(Name = "Course Name (Required)")]
        public string CourseName { get; set; }

        [Required(ErrorMessage = "Teacher Name required")]
        [Display(Name = "Teacher Name (Required)")]
        public string TeacherName { get; set; }

        [DataType(DataType.DateTime)]
        [Required(ErrorMessage = "Start Date required")]
        [Display(Name = "Start Date (Required)")]
        public DateTime StartDate { get; set; }

        [DataType(DataType.DateTime)]
        [Required(ErrorMessage = "End Date Required")]
        [Display(Name = "End Date (Required)")]
        public DateTime EndDate { get; set; }

        [Range(1, 50, ErrorMessage = "Spaces required")]
        public int Spaces { get; set; }
        public int Students { get; set; }
    }
}