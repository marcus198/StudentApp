﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace Student.Models
{
    public class StudentModel
    {
        [Required]
        [Display(Name = "Student ID")]
        [Range(100000, 999999, ErrorMessage = "You need to enter a valid Student ID")]
        public int StudentId { get; set; }

        [Required(ErrorMessage = "First Name required")]
        [Display(Name = "First Name (Required)")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Last Name required")]
        [Display(Name = "Last Name (Required)")]
        public string LastName { get; set; }

        [Required]
        [Range(1, 2, ErrorMessage = "Gender required")]
        [Display(Name = "Gender (Required)")]
        public int Gender { get; set; }

        [DataType(DataType.DateTime)]
        [Required(ErrorMessage = "Date of Birth required")]
        [Display(Name = "Date of birth (Required)")]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage = "Address line 1 required")]
        [Display(Name = "Address 1 (Required)")]
        public string Address1 { get; set; }

        [Required(ErrorMessage = "Address line 2 required")]
        [Display(Name = "Address 2 (Required)")]
        public string Address2 { get; set; }

        [Required(ErrorMessage = "Address line 3 required")]
        [Display(Name = "Address 3 (Required)")]
        public string Address3 { get; set; }
        public string Course1 { get; set; }
        public string Course2 { get; set; }
        public string Course3 { get; set; }
        public string Course4 { get; set; }
        public string Course5 { get; set; }
    }
}