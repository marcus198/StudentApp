﻿using Student.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DataLibrary;
using static DataLibrary.BusinessLogic.StudentProcessor;
using static DataLibrary.BusinessLogic.CourseProcessor;
using PagedList;

namespace Student.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
        public ActionResult ShowCoursesWithSpaces()
        {
            var courses = LoadCoursesWithSpace();
            List<CourseModel> courseList = new List<CourseModel>();
            foreach (var row in courses)
            {
                courseList.Add(new CourseModel
                {
                    CourseId = row.CourseId,
                    CourseName = row.CourseName,
                    TeacherName = row.CourseTeacher,
                    StartDate = row.StartDate,
                    EndDate = row.EndDate,
                    Spaces = row.Spaces,
                    Students = row.Students
                });
            }
            return View(courseList);
        }
        public ActionResult ShowStudentsNotMaxCourse()
        {
            var students = LoadStudentsNotMaxCourse();
            List<StudentModel> studentList = new List<StudentModel>();
            foreach (var row in students)
            {
                studentList.Add(new StudentModel
                {
                    StudentId = row.StudentId,
                    FirstName = row.FirstName,
                    LastName = row.LastName,
                    Gender = row.Gender,
                    DOB = row.DOB,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Address3 = row.Address3,
                    Course1 = row.Course1,
                    Course2 = row.Course2,
                    Course3 = row.Course3,
                    Course4 = row.Course4,
                    Course5 = row.Course5
                });
            }
            return View(studentList);
        }
        public ActionResult ShowStudentsInACourse()
        {
            return View("FilterStudentsInACourse");
        }
        [HttpPost]
        public ActionResult ShowStudentsInACourse(string currentFilter)
        {
            int id = Convert.ToInt32(currentFilter);
            var course = SelectCourse(id);
            List<StudentModel> studentList = new List<StudentModel>();
            if(course == null)
            {
                return RedirectToAction("FilterStudentCourses");
            }
            var students = LoadStudentsByCourseName(course.CourseName);
            foreach (var row in students)
            {
                studentList.Add(new StudentModel
                {
                    StudentId = row.StudentId,
                    FirstName = row.FirstName,
                    LastName = row.LastName,
                    Gender = row.Gender,
                    DOB = row.DOB,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Address3 = row.Address3,
                    Course1 = row.Course1,
                    Course2 = row.Course2,
                    Course3 = row.Course3,
                    Course4 = row.Course4,
                    Course5 = row.Course5
                });
            }
            return View(studentList);
        }
        public ActionResult ShowStudentCourses()
        {
            return View("FilterStudentCourses");
        }
        [HttpPost]
        public ActionResult ShowStudentCourses(string currentFilter)
        {
            int id = Convert.ToInt32(currentFilter);
            var student = SelectStudent(id);
            List<CourseModel> courseList = new List<CourseModel>();
            if(student == null)
            {
                return RedirectToAction("FilterStudentCourses");
            }

            var courses  = SelectCourseByNames(student.Course1, student.Course2, student.Course3, student.Course4, student.Course5);
            foreach (var row in courses)
            {
                courseList.Add(new CourseModel
                {
                    CourseId = row.CourseId,
                    CourseName = row.CourseName,
                    TeacherName = row.CourseTeacher,
                    StartDate = row.StartDate,
                    EndDate = row.EndDate,
                    Spaces = row.Spaces,
                    Students = row.Students
                });
            }
            return View(courseList);
        }
        public ActionResult ViewStudents(String currentFilter, String sortOrder, int? page)
        {
            ViewBag.Message = "Student List";

            var data = LoadStudents();
            List<StudentModel> students = new List<StudentModel>();
            foreach (var row in data)
            {
                students.Add(new StudentModel
                {
                    StudentId = row.StudentId,
                    FirstName = row.FirstName,
                    LastName = row.LastName,
                    Gender = row.Gender,
                    DOB = row.DOB,
                    Address1 = row.Address1,
                    Address2 = row.Address2,
                    Address3 = row.Address3,
                    Course1 = row.Course1,
                    Course2 = row.Course2,
                    Course3 = row.Course3,
                    Course4 = row.Course4,
                    Course5 = row.Course5
                });
            }
            if (!String.IsNullOrEmpty(currentFilter))
            {
                students = students.FindAll(s => s.FirstName.Contains(currentFilter) || s.LastName.Contains(currentFilter) || s.StudentId.ToString().Contains(currentFilter));//Where(s => s.FirstName.Contains(currentFilter)); //as List<StudentModel>;//Where(s => s.FirstName.Contains(currentFilter));
            }
            var pageNumber = page ?? 1;
            try
            {
                var onePageOfProducts = students.ToPagedList(pageNumber, 10);
                ViewBag.OnePageOfProducts = onePageOfProducts;
            }
            catch (Exception ex)
            {
                var errormsg = ex.InnerException.ToString();
                Console.Write(errormsg);
            }
            return View();
            //return View(students);
        }

        public ActionResult SignUp()
        {
            ViewBag.Message = "Student Sign Up.";
            var courses = LoadCourses();
            List<string> courseNames = new List<string>();

            foreach (var course in courses)
            {
                courseNames.Add(course.CourseName);
            }
            SelectList courseNamesSelectList = new SelectList(courseNames);
            ViewBag.courseList = courseNamesSelectList;

            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult SignUp(StudentModel studentmodel)
        {
            // Check that all selected courses are difference
            if(!String.IsNullOrEmpty(studentmodel.Course1) && (studentmodel.Course1 == studentmodel.Course2 || studentmodel.Course1 == studentmodel.Course3 || studentmodel.Course1 == studentmodel.Course4 || studentmodel.Course1 == studentmodel.Course5)
                || !String.IsNullOrEmpty(studentmodel.Course2) && (studentmodel.Course2 == studentmodel.Course1 || studentmodel.Course2 == studentmodel.Course3 || studentmodel.Course2 == studentmodel.Course4 || studentmodel.Course2 == studentmodel.Course5)
                || !String.IsNullOrEmpty(studentmodel.Course3) && (studentmodel.Course3 == studentmodel.Course1 || studentmodel.Course3 == studentmodel.Course2 || studentmodel.Course3 == studentmodel.Course4 || studentmodel.Course3 == studentmodel.Course5)
                || !String.IsNullOrEmpty(studentmodel.Course4) && (studentmodel.Course4 == studentmodel.Course1 || studentmodel.Course4 == studentmodel.Course2 || studentmodel.Course4 == studentmodel.Course3 || studentmodel.Course4 == studentmodel.Course5)
                || !String.IsNullOrEmpty(studentmodel.Course5) && (studentmodel.Course5 == studentmodel.Course1 || studentmodel.Course5 == studentmodel.Course2 || studentmodel.Course5 == studentmodel.Course3 || studentmodel.Course5 == studentmodel.Course4)
                )
            {
                // Not all required fields proplery filled out
                return View("ErrorWithData");
            }
            
            // Check if student already exists
            var stud = SelectStudent(studentmodel.StudentId);//mDataContext.Newsletters.Where(x => x.Email == newsletter.Email).FirstOrDefault();
            // Check if model is valid
            if (ModelState.IsValid)
            {
                // If student doesn't exist, create new record
                if (stud == null)
                {
                    // Assign number of records that have been added for info on debugging
                    int recordsCreated = CreateStudent(studentmodel.StudentId,
                        studentmodel.FirstName, studentmodel.LastName,
                        studentmodel.Gender, studentmodel.DOB,
                        studentmodel.Address1, studentmodel.Address2,
                        studentmodel.Address3,
                        studentmodel.Course1,
                        studentmodel.Course2,
                        studentmodel.Course3,
                        studentmodel.Course4,
                        studentmodel.Course5
                        );
                    //Update course db
                    UpdateCourseFromStudentEnrolment(studentmodel.Course1);
                    UpdateCourseFromStudentEnrolment(studentmodel.Course2);
                    UpdateCourseFromStudentEnrolment(studentmodel.Course3);
                    UpdateCourseFromStudentEnrolment(studentmodel.Course4);
                    UpdateCourseFromStudentEnrolment(studentmodel.Course5);
                    return RedirectToAction("ViewStudents");
                }
                else
                {
                    // Tell user that student already stored in database, so record not entered
                    return RedirectToAction("ErrorStudentIdExists");
                }
            }
            else
            {
                // Not all required fields proplery filled out
                return View("ErrorWithData");
            }
        }
        public ActionResult ErrorStudentIdExists()
        {
            return View("ErrorStudentIdExists");
        }
        public ActionResult ErrorWithData()
        {
            return View("ErrorWithData");
        }
        public ActionResult Delete(int id = 0)
        {
            // Fetch student from DB
            var row = SelectStudent(id);
            // Create model on front end from data library model
            StudentModel student = new StudentModel();
            student.StudentId = row.StudentId;
            student.FirstName = row.FirstName;
            student.LastName = row.LastName;
            student.Gender = row.Gender;
            student.DOB = row.DOB;
            student.Address1 = row.Address1;
            student.Address2 = row.Address2;
            student.Address3 = row.Address3;
            student.Course1 = row.Course1;
            student.Course2 = row.Course2;
            student.Course3= row.Course3;
            student.Course4 = row.Course4;
            student.Course5 = row.Course5;
            //Return view to ask use to confirm delete
            return View(student);
        }


        [HttpPost, ActionName("Delete")]
        public ActionResult DeletePerson(int id)
        {
            var s = SelectStudent(id);
            //Update course db
            if (s != null)
            {
                if (s.Course1 != null)
                {
                    UpdateCourseFromStudentDeletion(s.Course1);
                }
                if (s.Course2 != null)
                {
                    UpdateCourseFromStudentDeletion(s.Course2);
                }
                if (s.Course3 != null)
                {
                    UpdateCourseFromStudentDeletion(s.Course3);
                }
                if (s.Course4 != null)
                {
                    UpdateCourseFromStudentDeletion(s.Course4);
                }
                if (s.Course5 != null)
                {
                    UpdateCourseFromStudentDeletion(s.Course5);
                }
            }
            // Delete student from db
            var data = DeleteStudent(id);
            return RedirectToAction("ViewStudents");
        }

        public ActionResult Edit(int id = 0)
        {
            //Get list of course in db
            var courses = LoadCourses();
            List<string> courseNames = new List<string>();

            foreach (var course in courses)
            {
                courseNames.Add(course.CourseName);
            }
            SelectList courseNamesSelectList = new SelectList(courseNames);
            ViewBag.courseList = courseNamesSelectList;

            // Fetch student from DB
            var row = SelectStudent(id);

            // Create model on front end from data library model
            StudentModel student = new StudentModel();
            student.StudentId = row.StudentId;
            student.FirstName = row.FirstName;
            student.LastName = row.LastName;
            student.Gender = row.Gender;
            student.DOB = row.DOB;
            student.Address1 = row.Address1;
            student.Address2 = row.Address2;
            student.Address3 = row.Address3;

            //Return view to ask use to confirm delete
            return View(student);
        }

        [HttpPost, ValidateAntiForgeryToken]
        public ActionResult Edit(StudentModel s)
        {
            // Check that all selected courses are difference
            if (!String.IsNullOrEmpty(s.Course1) && (s.Course1 == s.Course2 || s.Course1 == s.Course3 || s.Course1 == s.Course4 || s.Course1 == s.Course5)
                || !String.IsNullOrEmpty(s.Course2) && (s.Course2 == s.Course1 || s.Course2 == s.Course3 || s.Course2 == s.Course4 || s.Course2 == s.Course5)
                || !String.IsNullOrEmpty(s.Course3) && (s.Course3 == s.Course1 || s.Course3 == s.Course2 || s.Course3 == s.Course4 || s.Course3 == s.Course5)
                || !String.IsNullOrEmpty(s.Course4) && (s.Course4 == s.Course1 || s.Course4 == s.Course2 || s.Course4 == s.Course3 || s.Course4 == s.Course5)
                || !String.IsNullOrEmpty(s.Course5) && (s.Course5 == s.Course1 || s.Course5 == s.Course2 || s.Course5 == s.Course3 || s.Course5 == s.Course4)
                )
            {
                // Not all required fields proplery filled out
                return View("ErrorWithData");
            }
            //Check course db
            var student = SelectStudent(s.StudentId);
            if(student.Course1 != null && s.Course1 == null)
            {
                UpdateCourseFromStudentDeletion(student.Course1);
            }
            if (student.Course2 != null && s.Course2 == null)
            {
                UpdateCourseFromStudentDeletion(student.Course2);
            }
            if (student.Course3 != null && s.Course3 == null)
            {
                UpdateCourseFromStudentDeletion(student.Course3);
            }
            if (student.Course4 != null && s.Course4 == null)
            {
                UpdateCourseFromStudentDeletion(student.Course4);
            }
            if (student.Course5 != null && s.Course5 == null)
            {
                UpdateCourseFromStudentDeletion(student.Course5);
            }

            //Update student
            var data = UpdateStudent(s.StudentId, s.FirstName, s.LastName, s.Gender, s.DOB, s.Address1, s.Address2, s.Address3, s.Course1, s.Course2, s.Course3, s.Course4, s.Course5);
            //Update course db
            UpdateCourseFromStudentEnrolment(s.Course1);
            UpdateCourseFromStudentEnrolment(s.Course2);
            UpdateCourseFromStudentEnrolment(s.Course3);
            UpdateCourseFromStudentEnrolment(s.Course4);
            UpdateCourseFromStudentEnrolment(s.Course5);
            return RedirectToAction("ViewStudents");
        }
    }
}