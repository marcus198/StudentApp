﻿using Student.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using static DataLibrary.BusinessLogic.CourseProcessor;

namespace Student.Controllers
{
    public class CourseController : Controller
    {
        // GET: Course
        public ActionResult ViewCourses()
        {
            ViewBag.Message = "Student List";

            var data = LoadCourses();
            List<CourseModel> courses = new List<CourseModel>();
            foreach (var row in data)
            {
                courses.Add(new CourseModel
                {
                    CourseId = row.CourseId,
                    CourseName = row.CourseName,
                    TeacherName = row.CourseTeacher,
                    StartDate = row.StartDate,
                    EndDate = row.EndDate,
                    Spaces = row.Spaces,
                    Students = row.Students
                });
            }

            return View(courses);
        }

        // GET: Course/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Course/Create
        public ActionResult Create()
        {
            return View("AddCourse");
        }

        // POST: Course/Create
        [HttpPost]
        public ActionResult Create(CourseModel course)
        {
            try
            {
                // Check if course already exists
                var crse = SelectCourse(course.CourseId);
                // Check if model is valid
                if (ModelState.IsValid)
                {
                    // If student doesn't exist, create new record
                    if (crse == null)
                    {
                        // Assign number of records that have been added for info on debugging
                        int recordsCreated = CreateCourse(course.CourseId,
                            course.CourseName, course.TeacherName,
                            course.StartDate, course.EndDate, course.Spaces, course.Students);
                        return RedirectToAction("ViewCourses");
                    }
                    else
                    {
                        // Tell user that course already stored in database, so record not entered
                        return RedirectToAction("CourseAlreadyExists");
                    }
                }
                else
                {
                    // Not all required fields proplery filled out
                    return View("AddCourse");
                }
            }
            catch
            {
                return View();
            }
        }

        // GET: Course/Edit/5
        public ActionResult Edit(int id)
        {
            // Fetch course from DB
            var row = SelectCourse(id);

            // Create model on front end from data library model
            CourseModel course = new CourseModel();
            course.CourseId = row.CourseId;
            course.CourseName = row.CourseName;
            course.TeacherName = row.CourseTeacher;
            course.StartDate = row.StartDate;
            course.EndDate = row.EndDate;
            course.Spaces = row.Spaces;
            course.Students = row.Students;

            //Return view to ask user to confirm delete
            return View(course);
        }

        // POST: Course/Edit/5
        [HttpPost]
        public ActionResult Edit(CourseModel course)
        {
            try
            {
                // Update logic
                var data = UpdateCourse(course.CourseId, course.CourseName, course.TeacherName, course.StartDate, course.EndDate, course.Spaces, course.Students);
                return RedirectToAction("ViewCourses");
            }
            catch
            {
                return View();
            }
        }

        // GET: Course/Delete/5
        public ActionResult Delete(int id = 0)
        {
            var row = SelectCourse(id);
            CourseModel course = new CourseModel();
            course.CourseId = row.CourseId;
            course.CourseName = row.CourseName;
            course.TeacherName = row.CourseTeacher;
            course.StartDate = row.StartDate;
            course.EndDate = row.EndDate;
            course.Spaces = row.Spaces;
            return View(course);
        }

        // POST: Course/Delete/5
        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteCrse(int id)
        {
            try
            {
                // Delete Logic
                var data = DeleteCourse(id);

                return RedirectToAction("ViewCourses");
            }
            catch
            {
                return View();
            }
        }
    }
}
